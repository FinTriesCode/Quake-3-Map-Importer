using UnityEngine;

namespace DefaultNamespace
{
    public class Quake3MapImporter : MonoBehaviour
    {
        
    }
}